#!/bin/bash
current_time=$(date +%s)
current_time_2=$((current_time*2))
echo "$current_time"
echo "$current_time_2"

for  i in {1..20}; do
echo "$i"
done
